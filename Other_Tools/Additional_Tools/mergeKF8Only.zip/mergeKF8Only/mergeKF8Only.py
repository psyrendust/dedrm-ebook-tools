#!/usr/bin/env python
# vim:fileencoding=UTF-8:ts=4:sw=4:sta:et:sts=4:ai

# Changelog
# 0.50 - replaces original mobi version with "KF8Only" Message in KF8 dual mobi ebooks

DEBUG = False

class Unbuffered:
    def __init__(self, stream):
        self.stream = stream
    def write(self, data):
        self.stream.write(data)
        self.stream.flush()
    def __getattr__(self, attr):
        return getattr(self.stream, attr)
import sys
sys.stdout=Unbuffered(sys.stdout)

import os, getopt, struct


def sortedHeaderKeys(mheader):
    hdrkeys = sorted(mheader.keys(), key=lambda akey: mheader[akey][0])
    return hdrkeys

class mergeKF8OnlyException(Exception):
    pass

class HdrParser:
    mobi_header = {
            'compress_type' : (0x00, '>H', 2),
            'fill0'         : (0x02, '>H', 2),
            'text_length'   : (0x04, '>L', 4),
            'text_records'  : (0x08, '>H', 2),
            'max_rec_size'  : (0x0a, '>H', 2),
            'crypto_type'   : (0x0c, '>H', 2),
            'fill1'         : (0x0e, '>H', 2),
            'magic'         : (0x10, '4s', 4),
            'header_length' : (0x14, '>L', 4),
            'type'          : (0x18, '>L', 4),
            'codepage'      : (0x1c, '>L', 4),
            'unique_id'     : (0x20, '>L', 4),
            'version'       : (0x24, '>L', 4),
            'metaorthindex' : (0x28, '>L', 4),
            'metainflindex' : (0x2c, '>L', 4),
            'index_names'   : (0x30, '>L', 4),
            'index_keys'    : (0x34, '>L', 4),
            'extra_index0'  : (0x38, '>L', 4),
            'extra_index1'  : (0x3c, '>L', 4),
            'extra_index2'  : (0x40, '>L', 4),
            'extra_index3'  : (0x44, '>L', 4),
            'extra_index4'  : (0x48, '>L', 4),
            'extra_index5'  : (0x4c, '>L', 4),
            'firstnontext'  : (0x50, '>L', 4),
            'title_offset'  : (0x54, '>L', 4),
            'title_length'  : (0x58, '>L', 4),
            'language_code' : (0x5c, '>L', 4),
            'dict_in_lang'  : (0x60, '>L', 4),
            'dict_out_lang' : (0x64, '>L', 4),
            'min_version'   : (0x68, '>L', 4),
            'firstaddl'     : (0x6c, '>L', 4),
            'huffoff'       : (0x70, '>L', 4),
            'huffnum'       : (0x74, '>L', 4),
            'hufftbloff'    : (0x78, '>L', 4),
            'hufftbllen'    : (0x7c, '>L', 4),
            'exth_flags'    : (0x80, '>L', 4),
            'fill3_a'       : (0x84, '>L', 4),
            'fill3_b'       : (0x88, '>L', 4),
            'fill3_c'       : (0x8c, '>L', 4),
            'fill3_d'       : (0x90, '>L', 4),
            'fill3_e'       : (0x94, '>L', 4),
            'fill3_f'       : (0x98, '>L', 4),
            'fill3_g'       : (0x9c, '>L', 4),
            'fill3_h'       : (0xa0, '>L', 4),
            'drm_unknown'   : (0xa4, '>L', 4),
            'drm_ptr'       : (0xa8, '>L', 4),
            'drm_count'     : (0xac, '>L', 4),
            'drm_size'      : (0xb0, '>L', 4),
            'drm_flags'     : (0xb4, '>L', 4),
            'fill4_a'       : (0xb8, '>L', 4),
            'fill4_b'       : (0xbc, '>L', 4),
            'first_content' : (0xc0, '>H', 2),
            'last_content'  : (0xc2, '>H', 2),
            'unknown0'      : (0xc4, '>L', 4),
            'fcis_index'    : (0xc8, '>L', 4),
            'fcis_count'    : (0xcc, '>L', 4),
            'flis_index'    : (0xd0, '>L', 4),
            'flis_count'    : (0xd4, '>L', 4),
            'unknown1'      : (0xd8, '>L', 4),
            'unknown2'      : (0xdc, '>L', 4),
            'srcs_index'    : (0xe0, '>L', 4),
            'srcs_count'    : (0xe4, '>L', 4),
            'unknown3'      : (0xe8, '>L', 4),
            'unknown4'      : (0xec, '>L', 4),
            'fill5'         : (0xf0, '>H', 2),
            'traildata_flag': (0xf2, '>H', 2),
            'ncxindex'      : (0xf4, '>L', 4),
            'unknown5'      : (0xf8, '>L', 4),
            'unknown6'      : (0xfc, '>L', 4),
            'datp_index'    : (0x100, '>L', 4),
            }


    mobi_header_sorted_keys = sortedHeaderKeys(mobi_header)

    def __init__(self, header):
        self.header = header
        self.hdr = {}
        self.extra = self.header[0x104:]
        for key in HdrParser.mobi_header_sorted_keys:
            (pos, format, tot_len) = HdrParser.mobi_header[key]
            val, = struct.unpack_from(format, self.header, pos)
            self.hdr[key] = val
        self.exth = ''
        if self.hdr['exth_flags'] & 0x40:
            exth_offset = 16 + self.hdr['header_length']
            self.exth = self.header[exth_offset:]
            self.extra = self.header[0x104: exth_offset]

    def dumpHeaderInfo(self):
        for key in HdrParser.mobi_header_sorted_keys:
            (pos, format, tot_len) = HdrParser.mobi_header[key]
            if key != 'magic':
                fmt_string = "  Key: %16s   Offset: 0x%03x   Width:  %d   Value: 0x%0" + str(tot_len) + "x"
            else:
                fmt_string = "  Key: %16s   Offset: 0x%03x   Width:  %d   Value: %s"
            print fmt_string % (key, pos, tot_len, self.hdr[key])
        print "Extra Region Length: ", len(self.extra)
        print "EXTH Region Length: ", len(self.exth)
        print "EXTH MetaData"
        self.dump_exth()
        return

    def sethdr(self, key, value):
        if key in HdrParser.mobi_header_sorted_keys:
            self.hdr[key] = value
            return
        if DEBUG:
            print "Header Write Error ", key, " does not exist"

    def gethdr(self, key):
        if key in HdrParser.mobi_header_sorted_keys:
            return self.hdr[key]
        if DEBUG:
            print "Header Read Error ", key, " does not exist"
        return none

    def buildHeader(self):
        hdata = []
        for key in HdrParser.mobi_header_sorted_keys:
            (pos, format, tot_len) = HdrParser.mobi_header[key]
            hdata.append(struct.pack(format, self.hdr[key]))
        hdata.append(self.extra)
        hdata.append(self.exth)
        return "".join(hdata)

    def exth_params(self):
        if self.exth != '':
            elen, enum = struct.unpack('>LL', self.exth[4:12])
            return elen, enum
        if DEBUG:
            print "Error EXTH region does not exist"
        return None, None

    # fixme: not actually tested since all combo KF8 mobis seem to always have a exth region - need to check header_length first
    def create_exth(self):
        self.hdr['exth_flags'] = self.hdr['exth_flags'] | 0x00000040
        self.exth = 'EXTH' + struct.pack('>L',0) + struct.pack('>L',0)
        exth_offset = 16 + self.hdr['header_length']
        shift = exth_offset - 0x104
        pad = 0
        if shift > len(self.extra):
            pad = shift - len(self.extra)
            self.extra += '\0' * pad
        newextra = self.extra[0:shift]
        self.exth = self.exth + self.extra[shift:]
        self.extra = newextra
        self.hdr['title_offset'] = self.hdr['title_offset'] + 12 + pad

    def add_exth(self,exth_num,exth_bytes):
        if self.exth == '':
            self.create_exth()
        elen,enum = self.exth_params()
        newrecsize = 8+len(exth_bytes)
        newexth = self.exth[0:4] + struct.pack('>L',elen+newrecsize)+struct.pack('>L',enum+1)
        newexth += struct.pack('>L',exth_num)+struct.pack('>L',newrecsize)+exth_bytes+self.exth[12:]
        self.hdr['title_offset'] = self.hdr['title_offset'] + newrecsize
        self.exth = newexth

    def read_exth(self, exth_num):
        if self.exth == '':
            return ''
        elen,enum = self.exth_params()
        ebase = 12
        while enum>0:
            exth_id, num_bytes = struct.unpack_from('>LL',self.exth, ebase)
            if exth_id == exth_num:
                return self.exth[ebase+8:ebase + num_bytes]
            enum -= 1
            ebase += num_bytes
        return ''

    def write_exth(self,exth_num,exth_bytes):
        if self.exth == '':
            if DEBUG:
                print "Error: EXTH region does not exist"
            return
        elen,enum = self.exth_params()
        ebase_idx = 12
        enum_idx = enum
        while enum_idx>0:
            exth_id, num_bytes = struct.unpack_from('>LL',self.exth,ebase_idx)
            if exth_id == exth_num:
                newlen = len(exth_bytes) + 8
                oldlen = num_bytes
                dif = newlen - oldlen
                if dif != 0:
                    self.hdr['title_offset'] = self.hdr['title_offset'] + dif
                newexth = self.exth[0:4] + struct.pack('>L', elen+dif)
                newexth += struct.pack('>L', enum) + self.exth[12:ebase_idx+4]
                newexth += struct.pack('>L', newlen) + exth_bytes + self.exth[ebase_idx+oldlen:]
                self.exth = newexth
                return
            enum_idx -= 1
            ebase_idx += num_bytes
        if DEBUG:
            print "EXTH Write Error element number ", exth_num, " does not exist"
        return

    def del_exth(self, exth_num):
        if self.exth == '':
            return
        elen,enum = self.exth_params()
        ebase_idx = 12
        enum_idx = enum
        while enum_idx>0:
            exth_id, num_bytes = struct.unpack_from('>LL',self.exth,ebase_idx)
            if exth_id == exth_num:
                dif = num_bytes
                self.hdr['title_offset'] = self.hdr['title_offset'] - dif
                newexth = self.exth[0:4] + struct.pack('>L', elen-dif)
                newexth += struct.pack('>L', enum-1) + self.exth[12:ebase_idx]
                newexth += self.exth[ebase_idx + dif:]
                self.exth = newexth
                return
            enum_idx -= 1
            ebase_idx += num_bytes
        return

    def dump_exth(self):
        if self.exth == '':
            return
        elen,enum = self.exth_params()
        ebase_idx = 12
        enum_idx = enum
        while enum_idx>0:
            exth_id, num_bytes = struct.unpack_from('>LL',self.exth,ebase_idx)
            contents = self.exth[ebase_idx+8:ebase_idx + num_bytes]
            print "     Key: %03d   Contents: %s" % (exth_id,  contents.encode('hex'))
            enum_idx -= 1
            ebase_idx += num_bytes




class PalmDB:
    # important  palmdb header offsets
    unique_id_seed = 68
    number_of_pdb_records = 76
    first_pdb_record = 78

    def __init__(self, palmdata):
        self.data = palmdata

    def getPalmData(self):
        return self.data

    def getsecaddr(self,secno):
        nsec, = struct.unpack_from('>H',self.data,PalmDB.number_of_pdb_records)
        if DEBUG:
            assert secno>=0 & secno<nsec,'secno %d out of range (nsec=%d)'%(secno,nsec)
        secstart, = struct.unpack_from('>L', self.data, PalmDB.first_pdb_record+secno*8)
        if secno == nsec-1:
            secend = len(self.data)
        else:
            secend, = struct.unpack_from('>L',self.data,PalmDB.first_pdb_record+(secno+1)*8)
        return secstart,secend

    def readsection(self,secno):
        secstart, secend = self.getsecaddr(secno)
        return self.data[secstart:secend]

    def writesection(self,secno,secdata): # overwrite, accounting for different length
        self.deletesectionrange(secno, secno)
        self.insertsection(secno, secdata)

    def nullsection(self,secno): # make it zero-length without deleting it
        datalst = []
        nsec, = struct.unpack_from('>H',self.data,PalmDB.number_of_pdb_records)
        secstart, secend = self.getsecaddr(secno)
        zerosecstart, zerosecend = self.getsecaddr(0)
        dif =  secend-secstart
        datalst.append(self.data[:PalmDB.first_pdb_record])
        for i in range(0,secno+1):
            ofs, flgval = struct.unpack_from('>2L',self.data,PalmDB.first_pdb_record+i*8)
            datalst.append(struct.pack('>L',ofs) + struct.pack('>L', flgval))
        for i in range(secno+1, nsec):
            ofs, flgval = struct.unpack_from('>2L',self.data,PalmDB.first_pdb_record+i*8)
            ofs = ofs - dif
            datalst.append(struct.pack('>L',ofs) + struct.pack('>L',flgval))
        lpad = zerosecstart - (PalmDB.first_pdb_record + 8*nsec)
        if lpad > 0:
            datalst.append('\0' * lpad)
        datalst.append(self.data[zerosecstart: secstart])
        datalst.append(self.data[secend:])
        self.data = "".join(datalst)

    def deletesectionrange(self,firstsec,lastsec): # delete a range of sections
        datalst = []
        firstsecstart,firstsecend = self.getsecaddr(firstsec)
        lastsecstart,lastsecend = self.getsecaddr(lastsec)
        zerosecstart, zerosecend = self.getsecaddr(0)
        dif = lastsecend - firstsecstart + 8*(lastsec-firstsec+1)
        nsec, = struct.unpack_from('>H',self.data,PalmDB.number_of_pdb_records)
        datalst.append(self.data[:PalmDB.unique_id_seed])
        datalst.append(struct.pack('>L',2*(nsec-(lastsec-firstsec+1))+1))
        datalst.append(self.data[PalmDB.unique_id_seed+4:PalmDB.number_of_pdb_records])
        datalst.append(struct.pack('>H',nsec-(lastsec-firstsec+1)))
        newstart = zerosecstart - 8*(lastsec-firstsec+1)
        for i in range(0,firstsec):
            ofs, flgval = struct.unpack_from('>2L',self.data,PalmDB.first_pdb_record+i*8)
            ofs = ofs-8*(lastsec-firstsec+1)
            datalst.append(struct.pack('>L',ofs) + struct.pack('>L', flgval))
        for i in range(lastsec+1,nsec):
            ofs, flgval = struct.unpack_from('>2L',self.data,PalmDB.first_pdb_record+i*8)
            ofs = ofs - dif
            flgval = 2*(i-(lastsec-firstsec+1))
            datalst.append(struct.pack('>L',ofs) + struct.pack('>L',flgval))
        lpad = newstart - (PalmDB.first_pdb_record + 8*(nsec - (lastsec - firstsec + 1)))
        if lpad > 0:
            datalst.append('\0' * lpad)
        datalst.append(self.data[zerosecstart:firstsecstart])
        datalst.append(self.data[lastsecend:])
        self.data = "".join(datalst)

    def insertsection(self,secno,secdata): # insert a new section
        datalst = []
        nsec, = struct.unpack_from('>H',self.data,PalmDB.number_of_pdb_records)
        secstart,secend = self.getsecaddr(secno)
        zerosecstart,zerosecend = self.getsecaddr(0)
        dif = len(secdata)
        datalst.append(self.data[:PalmDB.unique_id_seed])
        datalst.append(struct.pack('>L',2*(nsec+1)+1))
        datalst.append(self.data[PalmDB.unique_id_seed+4:PalmDB.number_of_pdb_records])
        datalst.append(struct.pack('>H',nsec+1))
        newstart = zerosecstart + 8
        totoff = 0
        for i in range(0,secno):
            ofs, flgval = struct.unpack_from('>2L',self.data,PalmDB.first_pdb_record+i*8)
            ofs += 8
            datalst.append(struct.pack('>L',ofs) + struct.pack('>L', flgval))
        datalst.append(struct.pack('>L', secstart + 8) + struct.pack('>L', (2*secno)))
        for i in range(secno,nsec):
            ofs, flgval = struct.unpack_from('>2L',self.data,PalmDB.first_pdb_record+i*8)
            ofs = ofs + dif + 8
            flgval = 2*(i+1)
            datalst.append(struct.pack('>L',ofs) + struct.pack('>L',flgval))
        lpad = newstart - (PalmDB.first_pdb_record + 8*(nsec + 1))
        if lpad > 0:
            datalst.append('\0' * lpad)
        datalst.append(self.data[zerosecstart:secstart])
        datalst.append(secdata)
        datalst.append(self.data[secstart:])
        self.data = "".join(datalst)



class Mobi7Replace:

    def __init__(self, infile):
        self.datain = file(infile, 'rb').read()
        self.pp = PalmDB(self.datain)
        self.rec0 = self.pp.readsection(0)
        self.boundary_rec = -1
        self.m7rec0 = ''
        self.hp = HdrParser(self.rec0)
        self.crypto_type = self.hp.gethdr('crypto_type')
        self.combo = False
        ver = self.hp.gethdr('version')
        if ver != 8:
            exth121 = self.hp.read_exth(121)
            if len(exth121) >  0:
                self.combo = True
        if self.combo:
            self.boundary_rec, = struct.unpack_from('>L',exth121,0)
            self.m7rec0 = self.rec0

        if DEBUG:
            print "version: ", ver
            print "crypto_type: ", self.crypto_type
            print "combo KF8: ", self.combo
            print "boundary_rec: ", self.boundary_rec

        if DEBUG:
            print "Original Header"
            self.hp.dumpHeaderInfo()



    def isKF8Combo(self):
        return self.combo

    def isEncrypted(self):
        return self.crypto_type != 0

    def getResult(self):
        return self.pp.getPalmData()


    def mergeMessage(self, messfile):

        def new_location(del_lst, val):
            if val == 0xffffffff:
                return val
            diff = 0
            for secnum in del_lst:
                if val > secnum:
                    diff += 1
                else:
                    break
            return val - diff

        self.message = file(messfile, 'rb').read()
        self.hp.sethdr('text_length', len(self.message))

        # parse the text records from the mobi7 header
        records = self.hp.gethdr('text_records')

        self.hp.sethdr('text_records',1)
        # set codepage to utf-8
        self.hp.sethdr('codepage', 65001)

        # create list of all sections to be deleted
        del_lst = []
        for i in xrange(2,records+1):
            del_lst.append(i)

        # identify any Huffdic compression dictionaries to be removed
        compression = self.hp.gethdr('compress_type')
        if compression == 0x4448:
            huffoff = self.hp.gethdr('huffoff')
            huffnum = self.hp.gethdr('huffnum')
            for i in xrange(0, huffnum):
                del_lst.append(i+huffoff)
            hufftbloff = self.hp.gethdr('hufftbloff')
            del_lst.append(hufftbloff)
            self.hp.sethdr('huffoff', 0xffffffff)
            self.hp.sethdr('huffnum', 0)
            self.hp.sethdr('hufftbloff', 0xffffffff)
            self.hp.sethdr('hufftbllen', 0)


        # don't use compression for this simple message
        self.hp.sethdr('compress_type', 1)

        # see if there is an NCX Index that needs to be dealt with as well
        ncxidx = self.hp.gethdr('ncxindex')
        if ncxidx != 0xffffffff:
            for i in xrange(3):
                del_lst.append( i + ncxidx)
            self.hp.sethdr('ncxindex', 0xffffffff)

        # set trailing data flags to be multibyte 1
        self.hp.sethdr('traildata_flag',1)

        # simply remove pointers to any dictionaries indexes
        # should not exist unless dictionary so just set them to 0xffffffff
        self.hp.sethdr('metaorthindex', 0xffffffff)
        self.hp.sethdr('metainflindex', 0xffffffff)
        self.hp.sethdr('index_names',   0xffffffff)
        self.hp.sethdr('index_keys',    0xffffffff)
        self.hp.sethdr('extra_index0',  0xffffffff)
        self.hp.sethdr('extra_index1',  0xffffffff)
        self.hp.sethdr('extra_index2',  0xffffffff)
        self.hp.sethdr('extra_index3',  0xffffffff)
        self.hp.sethdr('extra_index4',  0xffffffff)
        self.hp.sethdr('extra_index5',  0xffffffff)

        # del_lst should be final so sort it
        del_lst = sorted(del_lst)

        # at the proper message length to the FCIS section only if needed
        fcis_secnum = self.hp.gethdr('fcis_index')
        if fcis_secnum != 0xffffffff:
            fcis_info = self.pp.readsection(fcis_secnum)
            fcis_info = fcis_info[:0x14] + struct.pack('>L',len(self.message)) + fcis_info[0x18:]
            self.pp.writesection(fcis_secnum, fcis_info)

        # get update section number pointers that need to be updated
        self.hp.sethdr( 'firstnontext',  new_location( del_lst, self.hp.gethdr('firstnontext')  ) )
        self.hp.sethdr( 'firstaddl',     new_location( del_lst, self.hp.gethdr('firstaddl')     ) )
        self.hp.sethdr( 'first_content', new_location( del_lst, self.hp.gethdr('first_content') ) )
        self.hp.sethdr( 'last_content',  new_location( del_lst, self.hp.gethdr('last_content')  ) )
        self.hp.sethdr( 'fcis_index',    new_location( del_lst, self.hp.gethdr('fcis_index')    ) )
        self.hp.sethdr( 'flis_index',    new_location( del_lst, self.hp.gethdr('flis_index')    ) )
        self.hp.sethdr( 'srcs_index',    new_location( del_lst, self.hp.gethdr('srcs_index')    ) )
        self.hp.sethdr( 'datp_index',    new_location( del_lst, self.hp.gethdr('datp_index')    ) )

        # add multibyte trailing data that will be removed in the trailing data routine
        self.message += '\0'

        # finally update any exth metadata that needs updating
        # remove StartOffset from metadata
        self.hp.del_exth(116)

        # update the boundary rec for where it needs to be
        self.boundary_rec = new_location(del_lst, self.boundary_rec)
        self.hp.write_exth(121, struct.pack('>L', self.boundary_rec))

        # create the new mobi 7 header with all changes
        self.m7rec0 = self.hp.buildHeader()

        if DEBUG:
            print "Revised Header"
            self.hp.dumpHeaderInfo()

        # delete sections in reverse order
        # for efficiency build up non-overlapping list of ranges to use with deletesectionrange
        del_lst = sorted(del_lst, reverse=True)
        n = len(del_lst)
        if n > 0:
            rng_lst = []
            beg = del_lst[0]
            end = del_lst[0]
            for i in xrange(1, n):
                sec = del_lst[i]
                if sec == (beg - 1):
                    beg = sec
                else:
                    rng_lst.append([beg, end])
                    beg = sec
                    end = sec
            rng_lst.append([beg,end])
            for [beg, end] in rng_lst:
                self.pp.deletesectionrange(beg, end)

        # write out message to the first section after the header
        self.pp.writesection(1, self.message)

        # write out the revised mobi7 header
        self.pp.writesection(0,self.m7rec0)

        # Keep for Reference Only
        # code that explains how trailing data trimming works
        # multibyte = 0
        # trailers = 0
        # if self.sect.ident == 'BOOKMOBI':
        #       mobi_length, = struct.unpack_from('>L', self.header, 0x14)
        #       mobi_version, = struct.unpack_from('>L', self.header, 0x68)
        #       if (mobi_length >= 0xE4) and (mobi_version >= 5):
        #               flags, = struct.unpack_from('>H', self.header, 0xF2)
        #               multibyte = flags & 1
        #               while flags > 1:
        #                       if flags & 2:
        #                               trailers += 1
        #                       flags = flags >> 1

        return


def makeKF8Only(infile, messfile, outfile):

    # verify it is a mobi
    inf = file(infile, 'rb')
    header = inf.read(78)
    ident = header[0x3C:0x3C+8]
    inf.close()
    if ident != 'BOOKMOBI':
        raise mergeKF8OnlyException('invalid file format')

    m7r = Mobi7Replace(infile)
    if not m7r.isKF8Combo():
        raise mergeKF8OnlyException('not a KF8 dual Mobi file')
    if m7r.isEncrypted():
        raise mergeKF8OnlyException('ebook is encrypted')

    m7r.mergeMessage(messfile)
    file(outfile,'wb').write(m7r.getResult())
    return


def usage(progname):
    print ""
    print "Description:"
    print "   In a dual Kf8 mobi file, replaces the original mobi portion"
    print "   with a KF8Only message, leaving the KF8 portion untouched. "
    print "  "
    print "Usage:"
    print "  %s -h -d infile.mobi message outfile.mobi" % progname
    print "  "
    print "Options:"
    print "    -h           print this help message"
    print "    -d           use verbose debugging"


def main(argv=sys.argv):
    global DEBUG
    print "mergeKF8Only 0.51"
    print "    based on mobi_unpack.py code by: Charles M. Hannum, P. Durrant,"
    print "    K. Hendricks, S. Siebert, fandrieu, DiapDealer, and nickredding."
    progname = os.path.basename(argv[0])
    try:
        opts, args = getopt.getopt(sys.argv[1:], "hd")
    except getopt.GetoptError, err:
        print str(err)
        usage(progname)
        sys.exit(2)

    if len(args) != 3:
        usage(progname)
        sys.exit(2)

    for o, a in opts:
        if o == "-d":
            DEBUG = True
        if o == "-h":
            usage(progname)
            sys.exit(0)

    infile, messfile, outfile = args
    infileext = os.path.splitext(infile)[1].upper()
    if infileext not in ['.MOBI', '.PRC']:
        print "Error: first parameter must be a Kindle/Mobipocket ebook."
        return 1

    try:
        print 'Merging KF8Only message...'
        makeKF8Only(infile, messfile, outfile)
        print 'Completed'

    except ValueError, e:
        print "Error: %s" % e
        return 1

    return 0


if __name__ == '__main__':
    sys.stdout=Unbuffered(sys.stdout)
    sys.exit(main())
